package Inferred::Bar;
use Moose;



__PACKAGE__->meta->make_immutable;
no Moose;

1;
