package ClassC;

use Test::Class::Moose;

sub test_c {
    ok( 1, 'package C' );
}

1;
