package LoadTests::Success;

use strict;
use warnings;

use Fail;

1;
