package ClassE;

use Test::Class::Moose;

sub test_e {
    ok( 1, 'package E' );
}

1;
