package Test::Mock::Class::Test::Dummy;

use Moose;

sub a_method {
    return 1;
};

sub another_method {
    return 1;
};

1;
