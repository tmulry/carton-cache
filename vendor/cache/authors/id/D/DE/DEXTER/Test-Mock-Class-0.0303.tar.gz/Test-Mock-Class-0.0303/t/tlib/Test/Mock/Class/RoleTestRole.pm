package Test::Mock::Class::RoleTestRole;

use Moose::Role;

sub test_role_method {
    1;
};

1;
