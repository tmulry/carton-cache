#!/usr/bin/perl -I../lib

use strict;
use warnings;

use Fatal::Exception 'Exception::System' => 'system';
