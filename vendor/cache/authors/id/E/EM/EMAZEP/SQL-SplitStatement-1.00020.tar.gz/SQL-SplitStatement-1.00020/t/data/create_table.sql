CREATE TABLE foo (
    foo_field_1 VARCHAR,
    foo_field_2 VARCHAR
);
-- Internal comment
CREATE TABLE bar (
    bar_field_1 VARCHAR,
    bar_field_2 VARCHAR
);